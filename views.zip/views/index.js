<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width, initial-scale=1">
	<title>VITCC - Log In</title>
	<link rel="stylesheet" type="text/css" href="/stylesheets/style.css">
	<link rel="icon" href="images/icon.png">
</head>
</head>
<body>
	<div class="back">
	</div>

	<div class="log">
		<p><h1>VITCC</h1>
		Log In</p>
		<form action='/login' method="POST">
			<h7 style="color: red;font-size: 22px"><%= wronglogin %></h7>
			<input type="text" name="username" placeholder="Username" class="field">
			<input type="password" name="password" placeholder="Password" class="field">
			<input type="submit" name="" class="sub" value='Log In'></a>
		</form><br><br<br>
		<a href='/about' target='_blank' class="connect">Connect your Chapter/Club - Its FREE!</a></p>
	</div>
</body>
</html>