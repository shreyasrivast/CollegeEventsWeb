<!DOCTYPE html>
<html>
<head>
	<title>VITCC - Home</title>
	<link rel="stylesheet" type="text/css" href="stylesheets/style_home.css">
	<script src="javascripts/slider.js"></script>
	<meta name='viewport' content="width=device-width, initial-scale=1">
	<link rel="icon" href="images/icon.png">
</head>

<body>
<div id="background">
	<img src="stylesheets/Picture.png">
</div>

<img src="images/menubutton.png" id="menubutton" onclick="transition_sidebar()">
<div class="sidebar" id='sidebar'>
	<ul>
		<li onclick="transition_sidebar()"><img src="images/home.png">Home</li>
		<a href="/meeting"><li><img src="images/meeting.png">Meeting</li></a>
		
		<a href="/event"><li><img src="images/event.png">Events</li></a>
		<a href="/project"><li><img src="images/project.png">Projects</li></a>
		<a href="/logout"><li><img src="images/logout.png">Logout</li></a>
	</ul>
</div>

<div id="main_window" style="text-align: center">
		<h3>Welcome <%= firstname %></h3>
		<h7>See what <%= chapter %> is upto today</h7>
		<div>&nbsp;</div>
		<% updates.forEach(function(update) { %>
                    <div style="font-size: 22px"><%= update %></div>
                    <% }); %>

</div>
</body>
</html>