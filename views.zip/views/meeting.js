<!DOCTYPE html>
<html>
<head>
	<title>VITCC - Meetings</title>
	<link rel="stylesheet" type="text/css" href="stylesheets/style_home.css">
	<script src="javascripts/slider.js"></script>
	<meta name='viewport' content="width=device-width, initial-scale=1">
	<link rel="icon" href="images/icon.png">
</head>
</head>

<body>
<div id="background">
	<img src="stylesheets/Picture.png">
</div>

<img src="images/menubutton.png" id="menubutton" onclick="transition_sidebar()">
<div class="sidebar" id='sidebar'>
	<ul>
		<a href="/home"><li><img src="images/home.png">Home</li></a>
		<li onclick="transition_sidebar()"><img src="images/meeting.png">Meetings</li>
		
		<a href="/event"><li><img src="images/event.png">Events</li></a>
		<a href="/project"><li><img src="images/project.png">Projects</li></a>
		<a href="/logout"><li><img src="images/logout.png">Logout</li></a>
	</ul>
</div>

<div id="main_window">
		<p class="content"><h3 align="center">Meetings</h3>
		<h7 style="text-align: center;width: 100%;display: block;font-size: 23px;color: red"><%= postedMeeting %></h7>
			<ul class="meetlist">

				<li><%= firstMeetingVenue %><span class="date">-&nbsp;<%= firstMeetingTimeAndDate %></span></li><br>

				<span id='meet'>

					<% for(var i=0 ; i<otherMeetingsVenue.length ; i++) {%>

					<li><%= otherMeetingsVenue[i] %><span class="date">-&nbsp;<%= otherMeetingsTimeAndDate[i] %></span></li>
					<br>
					<% } %>
				</span>
			</ul>
			<form id="form" action="/meeting/postMeeting" onsubmit="return validateMeeting()" method="POST">
				<input type="text" name="venue" id=v placeholder="Venue">
				<input type="date" name="date" id=d placeholder="Date">
				<input type="time" name="time" id=t placeholder="Time">
				<input type="submit" id='pub'>
			</form>
			<span class="buttmar">
			<button id="sub" onclick="show(0)">View all</button>
			<button id="post" onclick="inp(0)">Post a meeting</button><br><br>
			</span>
			</p>
	</div>
</body>
</html>