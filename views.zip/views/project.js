<!DOCTYPE html>
<html>
<head>
	<title>VITCC - Project</title>
	<link rel="stylesheet" type="text/css" href="stylesheets/style_home.css">
	<script src="javascripts/slider.js"></script>
	<meta name='viewport' content="width=device-width, initial-scale=1">
	<link rel="icon" href="images/icon.png">
	<style type="text/css">
		table
		{
			width: 100%;
			font-size: 20px;
		}
		th, td, tr
		{
			border: solid 1px;
		}
	</style>
</head>
</head>

<body>
<div id="background">
	<img src="stylesheets/Picture.png">
</div>

<img src="images/menubutton.png" id="menubutton" onclick="transition_sidebar()">
<div class="sidebar" id='sidebar'>
	<ul>
		<a href="/home"><li><img src="images/home.png">Home</li></a>
		<a href="/meeting"><li><img src="images/meeting.png">Meetings</li></a>
	
		<a href="/event"><li><img src="images/event.png">Events</li></a>
		<li onclick="transition_sidebar()"><img src="images/project.png">Projects</li>
		<a href="/logout"><li><img src="images/logout.png">Logout</li></a>
	</ul>
</div>

<div id="main_window">
		<div style="width:100%;text-align: center;font-size: 24px;margin-top: 35px;color: green;text-shadow: 0 0 10px white"><%= postedProject %></div>
		<h3 align="center">Projects</h3>
		<div>
			<form action="/project/postProject" method="POST" enctype="multipart/form-data">

			
			<input type="file" name="pdfFile" accept="application/pdf" id='projectFile'>
			<input type="submit" onclick="return validateProject()" style="cursor:pointer;margin-top: 50px;width:25%;margin-bottom: 20px">
				
			</form>
		</div>
		<div style="text-align: center;border-top: solid 1px;">
			<h3>Submitted Projects</h3>

			<table>
				<tr>
					<th>S.no</th>
					
					<th>Submitted By</th>
					<th>Date</th>
					<th>Download</th>
				</tr>
				<% for(var i=0 ; i<namesArray.length ; i++)
				{%>
				<tr>
					<td>
						<%= i+1 %>
					</td>
					
					<td>
						<%= namesArray[i] %>
					</td>
					<td>
						<%= dateArray[i] %>
					</td>
					<td>
						<a target="_blank" href='projects/<%= idArray[i] %>.pdf'>Download</a>
					</td>
				</tr>
				<% } %>
			</table>
		</div>
	</div>
</body>
</html>