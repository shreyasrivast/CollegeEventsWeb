var sidebarShown=0;
function transition_sidebar()
{
	if(sidebarShown==1)
	{
		hide_sidebar();
	}
	else
	{
		display_sidebar();
	}
}

function display_sidebar() 
{
	if(window.innerWidth<850)
	{
		document.getElementById('sidebar').style.left='0';
		document.getElementById('main_window').style.marginLeft='70%';
	}
	else
	{
		document.getElementById('sidebar').style.left='0';
		document.getElementById('main_window').style.marginLeft='30%';	
	}
	sidebarShown=1;
	document.getElementById('background').style.height=window.innerHeight;
}

function hide_sidebar() 
{
	if(window.innerWidth<850)
	{
		document.getElementById('sidebar').style.left='-75%';
		document.getElementById('main_window').style.marginLeft='10%';
	}
	else
	{
		document.getElementById('sidebar').style.left='-25%';
		document.getElementById('main_window').style.marginLeft='10%';
	}
	sidebarShown=0;
}
var h=[0,0];
function show(i){
	if(!h[i]){
		if(!i)
		document.getElementById('sub').innerHTML='View less';
	else
		document.getElementById('sub').innerHTML="Veiw less";
		document.getElementById('meet').style.display='initial';
		h[i]=1;
	}
	else{
		document.getElementById('sub').innerHTML='View all';
		document.getElementById('meet').style.display='none';
		h[i]=0;
	}
}
var f=[0,0];
function inp(j){
	if(!f[j]){
		if (!j)
		document.getElementById('post').innerHTML='Don`t Post';
	else
		document.getElementById('post').innerHTML='Don`t Create';
		document.getElementById('form').style.display='initial';
		f[j]=1;
	}
	else{
		if (!j)
		document.getElementById('post').innerHTML='Post a Meeting';
	else
		document.getElementById('post').innerHTML='Create an Event';
		document.getElementById('form').style.display='none';
		f[j]=0;
	}
}

function validateDateTime(date, time)
{
	
	var dateArr = date.split('-');
	var yearEntered = Number(dateArr[0]);
	var monthEntered = Number(dateArr[1]);
	var dateEntered = Number(dateArr[2]);

	var timeArr = time.split(':');
	var hourEntered = Number(timeArr[0]);
	var minuteEntered = Number(timeArr[1]);

	

	var d = new Date()
	var nowYear = d.getFullYear();
	var nowMonth = d.getMonth()+1;
	var nowDate = d.getDate();

	if(yearEntered>=nowYear)
	{
		if(monthEntered>=nowMonth)
		{
			if((dateEntered>nowDate) || (nowDate>=30 && dateEntered==1))
			{
				return true;
			}
		}
	}

	return false;

	
}


function validateEvent()
{
	var a=document.getElementById('d').value;
	var b=document.getElementById('t').value;
	if(a==''){
		alert('Please enter the Date');
		return false;
	}
	else if(b==''){
		alert('Please enter the Time');
		return false;
	}
	else if(document.getElementById('v').value==''){
		alert('Please enter the Description');
		return false;
	}
	else if(!validateDateTime(a, b))
	{
		alert("Old Date Entered");
		return false;
	}
	else
	{
		return true;
	}
}



function validateMeeting(){
	var a=document.getElementById('d').value;
	var b=document.getElementById('t').value;
	if(a==''){
		alert('Please enter the Date');
		return false;
	}
	else if(b==''){
		alert('Please enter the Time');
		return false;
	}
	else if(document.getElementById('v').value==''){
		alert('Please enter the Venue');
		return false;
	}
	else if(!validateDateTime(a, b))
	{
		alert("Old Date Entered");
		return false;
	}
	else
	{
		return true;
	}
}

function validateProject()
{

	console.log('i am h');
	var projectFile = document.getElementById('projectFile');

	if(projectFile.value == '')
	{
		console.log('i am s');
		alert('Please Select a File');
		return false;
	}
	else
	{
		return true;
	}

}




