var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
	if(req.session.memberId)
	{
		req.session.destroy();
		res.redirect('/?loggedout=1');
	}
	else
	{
		//res.end('session not destroyed, nor does the session exist');
		res.redirect('/?notlogin=1');
	}
});

module.exports = router;
