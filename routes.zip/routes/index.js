var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
	if(req.query.wronglogin)
	{
		res.render('index', { wronglogin: "That didn't match our database" });
	}
	else if(req.query.notlogin)
	{
		//res.end('');
		res.render('index', { wronglogin: "Please Login First to Continue" });
	}
	else if(req.query.loggedout)
	{
		res.render('index', { wronglogin: "Successfully Logged Out" });
	}
	else
	{
		res.render('index', { wronglogin: '' });
	}
});

router.get('/about', function(req, res, next) {
  res.render('about', {});
});

module.exports = router;
