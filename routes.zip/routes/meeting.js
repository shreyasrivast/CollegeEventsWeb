var express = require('express');
var database = require('../condb');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
	if(req.session.memberId)
	{
		var firstMeetingVenue = '';
		var firstMeetingTimeAndDate = '';
		var otherMeetingsVenue = ['', ''];
		var otherMeetingsTimeAndDate = ['', ''];

		var tempTime;
		var hours;
		var minutes;
		var suffix;
		var tempDate;

		var monthArray = ['', 'January', 'February', 'March', 'April', 'May', 
		'June', 'July', 'August', 'September',
		'October', 'November', 'December'];

		var today = new Date().toISOString().substr(0, 10);
		
		database.meetingsTable.find({date : {$gte : today}, chapter : req.session.chapter}).sort({'date' : 'asc'}).exec(function(err, foundData){

			for (var i=0 ; i<foundData.length ; i++)
			{
				tempTime = foundData[i].time.split(':');
				hours = (Number(tempTime[0])>12)? (Number(tempTime[0])-12) : Number(tempTime[0]);
				hours = (hours==0)? 12:hours;
				hours = (hours<10)? "0"+hours: ""+hours;
				minutes = tempTime[1];
				suffix = (Number(tempTime[0])>=12)? "PM" : "AM";
				tempTime = ""+hours+":"+minutes+" "+suffix;

				tempDate = foundData[i].date.split('-');
				tempDate[1] = monthArray[tempDate[1]];
				tempDate = tempDate[2]+" "+tempDate[1]+" "+tempDate[0];


				if(i==0)
				{
					firstMeetingVenue = foundData[i].place;
					firstMeetingTimeAndDate = tempTime+", "+tempDate;
				}
				else
				{
					otherMeetingsVenue[i-1] = foundData[i].place;
					otherMeetingsTimeAndDate[i-1] = tempTime+", "+tempDate;
				}
			}

			if(req.query.meetingPosted)
			{
				res.render('meeting', {

					'postedMeeting' : 'Meeting was successfully scheduled by you',
					'firstMeetingVenue' : firstMeetingVenue,
					'firstMeetingTimeAndDate' : firstMeetingTimeAndDate,
					'otherMeetingsVenue' : otherMeetingsVenue,
					'otherMeetingsTimeAndDate' : otherMeetingsTimeAndDate
				});
			}
			else if(req.query.foundMeeting)
			{
				res.render('meeting', {

					'postedMeeting' : 'Meeting already scheduled on this day',
					'firstMeetingVenue' : firstMeetingVenue,
					'firstMeetingTimeAndDate' : firstMeetingTimeAndDate,
					'otherMeetingsVenue' : otherMeetingsVenue,
					'otherMeetingsTimeAndDate' : otherMeetingsTimeAndDate
				});
			}
			else
			{
				res.render('meeting', {

					'postedMeeting' : '',
					'firstMeetingVenue' : firstMeetingVenue,
					'firstMeetingTimeAndDate' : firstMeetingTimeAndDate,
					'otherMeetingsVenue' : otherMeetingsVenue,
					'otherMeetingsTimeAndDate' : otherMeetingsTimeAndDate
				});
			}
			

		});

	}
	else
	{
		res.redirect('/?notlogin=1');
	}
});


router.post('/postMeeting', function(req, res, next){

	if(req.session.memberId)
	{

		var newMeeting = new database.meetingsTable();

		newMeeting.place = req.body.venue;
		newMeeting.date = req.body.date;
		newMeeting.time = req.body.time;
		newMeeting.postedBy = req.session.memberId;
		newMeeting.chapter = req.session.chapter;

		database.meetingsTable.find({"date" : req.body.date, "chapter" : req.session.chapter}, function(err, foundData){
			if(foundData.length>0)
			{
				//res.write('I found the data');
				res.redirect('/meeting?foundMeeting=1');
			}
			else
			{
				//res.write((""+foundData.length));
				//res.write('I didnt find anything, I am going to insert the object');
				newMeeting.save(function(err, savedObject){

					if(err)
					{
						res.end("error connecting the mongoDB");
						console.log(err);
					}
					else
					{

						res.redirect('/meeting?meetingPosted=1');
					}



				});
			}

		});
	}
	else
	{
		res.redirect('/?notlogin=1');
	}
});

module.exports = router;
