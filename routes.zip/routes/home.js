var express = require('express');
var database = require('../condb');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
	if(req.session.memberId)
	{
		var updates = [];
		var tempStr;
		var tempTime;
		
		var firstname = req.session.firstname;
		var chapter = req.session.chapter;

		var today = new Date().toISOString().substr(0, 10);

		database.meetingsTable.find({'date' : today}, function(err, foundData){

			if(foundData.length>0)
			{
				tempTime = foundData[i].time.split(':');
				hours = (Number(tempTime[0])>12)? (Number(tempTime[0])-12) : Number(tempTime[0]);
				hours = (hours==0)? 12:hours;
				hours = (hours<10)? "0"+hours: ""+hours;
				minutes = tempTime[1];
				suffix = (Number(tempTime[0])>=12)? "PM" : "AM";
				tempTime = ""+hours+":"+minutes+" "+suffix;
				
				tempStr = "You have a meeting today at "+foundData[0].place+" "+tempTime;
			}
			

		});



		res.render('home', {
			'firstname' : firstname, 
			'chapter' : chapter,
			'updates' : ['You have a meeting today at SMV 7:30pm', 'pLAY has posted a new project, do have a look']
		});
		
	}
	else
	{
		res.redirect('/?notlogin=1');
	}
});

module.exports = router;
