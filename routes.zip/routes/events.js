var express = require('express');
var database = require('../condb');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
	if(req.session.memberId)
	{
		var firstEventVenue = '';
		var firstEventTimeAndDate = '';
		var otherEventsVenue = ['', ''];
		var otherEventsTimeAndDate = ['', ''];

		var tempTime;
		var hours;
		var minutes;
		var suffix;
		var tempDate;

		var monthArray = ['', 'January', 'February', 'March', 'April', 'May', 
		'June', 'July', 'August', 'September',
		'October', 'November', 'December'];

		var today = new Date().toISOString().substr(0, 10);

		//res.render('event', {});


		database.eventsTable.find({date : {$gte : today}, chapter : req.session.chapter}).sort({'date' : 'asc'}).exec(function(err, foundData){

			for (var i=0 ; i<foundData.length ; i++)
			{
				tempTime = foundData[i].time.split(':');
				hours = (Number(tempTime[0])>12)? (Number(tempTime[0])-12) : Number(tempTime[0]);
				hours = (hours==0)? 12:hours;
				hours = (hours<10)? "0"+hours: ""+hours;
				minutes = tempTime[1];
				suffix = (Number(tempTime[0])>=12)? "PM" : "AM";
				tempTime = ""+hours+":"+minutes+" "+suffix;

				tempDate = foundData[i].date.split('-');
				tempDate[1] = monthArray[tempDate[1]];
				tempDate = tempDate[2]+" "+tempDate[1]+" "+tempDate[0];


				if(i==0)
				{
					firstEventVenue = foundData[i].title;
					firstEventTimeAndDate = tempTime+", "+tempDate;
				}
				else
				{
					otherEventsVenue[i-1] = foundData[i].title;
					otherEventsTimeAndDate[i-1] = tempTime+", "+tempDate;
				}
			}

			if(req.query.eventPosted)
			{
				res.render('event', {

					'postedEvent' : 'Event was successfully scheduled by you',
					'firstEventVenue' : firstEventVenue,
					'firstEventTimeAndDate' : firstEventTimeAndDate,
					'otherEventsVenue' : otherEventsVenue,
					'otherEventsTimeAndDate' : otherEventsTimeAndDate
				});
			}
			else if(req.query.foundEvent)
			{
				res.render('event', {

					'postedEvent' : 'Event already scheduled on this day',
					'firstEventVenue' : firstEventVenue,
					'firstEventTimeAndDate' : firstEventTimeAndDate,
					'otherEventsVenue' : otherEventsVenue,
					'otherEventsTimeAndDate' : otherEventsTimeAndDate
				});
			}
			else
			{
				res.render('event', {

					'postedEvent' : '',
					'firstEventVenue' : firstEventVenue,
					'firstEventTimeAndDate' : firstEventTimeAndDate,
					'otherEventsVenue' : otherEventsVenue,
					'otherEventsTimeAndDate' : otherEventsTimeAndDate
				});
			}
			

		});

	}
	else
	{
		res.redirect('/?notlogin=1');
	}
});


router.post('/postEvent', function(req, res, next){

	if(req.session.memberId)
	{

		var newEvent = new database.eventsTable();

		newEvent.title = req.body.eventName;
		newEvent.description = req.body.description;
		newEvent.date = req.body.date;
		newEvent.time = req.body.time;
		newEvent.postedBy = req.session.memberId;
		newEvent.chapter = req.session.chapter;

	


		database.eventsTable.find({"date" : req.body.date, "chapter" : req.session.chapter}, function(err, foundData){
			if(foundData.length>0)
			{
				//res.write('I found the data');
				res.redirect('/event?foundEvent=1');
			}
			else
			{
				//res.write((""+foundData.length));
				//res.write('I didnt find anything, I am going to insert the object');
				newEvent.save(function(err, savedObject){

					if(err)
					{
						res.end("error connecting the mongoDB");
						console.log(err);
					}
					else
					{
						res.redirect('/event?eventPosted=1');
					}



				});
			}

		});

	}
	else
	{
		res.redirect('/?notlogin=1');
	}
});

module.exports = router;
