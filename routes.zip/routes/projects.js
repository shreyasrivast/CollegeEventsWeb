var express = require('express');
var database = require('../condb');
var fs = require('fs');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
	if(req.session.memberId)
	{
		var nameArray = [];
		var dateArray = [];
		var titleArray = [];
		var idArray = [];

		var tempDate;

		var monthArray = ['', 'January', 'February', 'March', 'April', 'May', 
		'June', 'July', 'August', 'September',
		'October', 'November', 'December'];

		//res.render('project', {});
		//return;
		database.projectsTable.find({chapter : req.session.chapter}).sort({'date' : 'asc'}).exec(function(err, foundData){

			//res.end(""+foundData);
			//return;

			for (var i=0 ; i<foundData.length ; i++)
			{
				tempDate = foundData[i].date.split('-');
				tempDate[1] = monthArray[tempDate[1]];
				tempDate = tempDate[2]+" "+tempDate[1]+" "+tempDate[0];

				titleArray[i] = foundData[i].title;
				dateArray[i] = tempDate;
				idArray[i] = foundData[i].id;
				nameArray[i] = foundData[i].postedBy;
			}

			if(req.query.projectPosted)
			{
				res.render('project', {

					'postedProject' : 'Project Posted Successfully',
					'namesArray' : nameArray,
					'dateArray' : dateArray,
					'titleArray' : titleArray,
					'idArray' : idArray
				});
			}
			else
			{
				res.render('project', {

					'postedProject' : '',
					'namesArray' : nameArray,
					'dateArray' : dateArray,
					'titleArray' : titleArray,
					'idArray' : idArray
				});
			}
			

		});

	}
	else
	{
		res.redirect('/?notlogin=1');
	}
});


router.post('/postProjectss', function(req, res, next){

	if(req.session.memberId)
	{

		
		var newProject = new database.projectsTable();

		newProject.date = new Date().toISOString().substr(0, 10);
		newProject.title = req.body.title || "Title Here!";
		//res.end(""+req.body.title);
		//return;
		newProject.postedBy = req.session.firstname;
		newProject.chapter = req.session.chapter;

	
				newProject.save(function(err, savedObject){

					if(err)
					{
						res.end("error connecting the mongoDB");
						console.log(err);
					}
					else
					{
						fs.readFile(req.files.pdfFile.path, function(err, data){

							var newPath = __dirname +"/projects/"+savedObject.id+".pdf";
							fs.writeFile(newPath, data, function(err){
								res.redirect('/project?projectPosted=1');
							});

							
						});
						
					}

				});


	}
	else
	{
		res.redirect('/?notlogin=1');
	}
});

module.exports = router;
