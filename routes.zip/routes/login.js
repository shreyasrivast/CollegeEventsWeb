var express = require('express');
var database = require('../condb');
var router = express.Router();

/* GET home page. */
router.post('/', function(req, res, next) {
  
  database.membersTable.find({username: req.body.username, password: req.body.password}, function(err, foundData){

  		if(err)
  		{
  			console.log("Error in Connecting to the membersTable");
  			console.log(err);
  			res.end("Internal MongoDBError");
  		}
  		else
  		{
  			if(foundData.length == 1)
  			{
  				req.session.memberId = foundData[0]['_id'];
          req.session.chapter = foundData[0]['chapter'];
          req.session.firstname = foundData[0]['firstname'];
          res.redirect('/home');
  			}
  			else
  			{
  				res.redirect('/?wronglogin=1');
  			}
  		}

  });

});


module.exports = router;
